import pytest
from selenium import webdriver


@pytest.fixture
def driver():
    """
    Setup: Launch Chrome browser before each test.
    Teardown: Close browser after each test.
    """
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    driver = webdriver.Chrome(options=options)
    driver.implicitly_wait(10)
    yield driver
    driver.quit()