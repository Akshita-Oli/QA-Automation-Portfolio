from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class BasePage:
    """
    Base class for all page objects.
    Contains reusable methods shared across all pages.
    """

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)

    def find_element(self, locator):
        """Wait for element to be present and return it."""
        return self.wait.until(EC.presence_of_element_located(locator))

    def find_elements(self, locator):
        """Return all matching elements."""
        return self.driver.find_elements(*locator)

    def click(self, locator):
        """Wait for element and click it."""
        self.wait.until(EC.element_to_be_clickable(locator)).click()

    def type_text(self, locator, text):
        """Clear field and type text."""
        element = self.find_element(locator)
        element.clear()
        element.send_keys(text)

    def get_text(self, locator):
        """Return text content of element."""
        return self.find_element(locator).text

    def is_element_visible(self, locator):
        """Return True if element is visible, False otherwise."""
        try:
            return self.wait.until(EC.visibility_of_element_located(locator)).is_displayed()
        except Exception:
            return False
