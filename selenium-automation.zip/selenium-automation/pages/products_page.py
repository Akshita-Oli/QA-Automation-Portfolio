from selenium.webdriver.common.by import By
from pages.base_page import BasePage


class ProductsPage(BasePage):
    """
    Page Object for the SauceDemo Products/Inventory Page.
    URL: https://www.saucedemo.com/inventory.html
    """

    # Locators
    PAGE_TITLE       = (By.CLASS_NAME, "title")
    PRODUCT_ITEMS    = (By.CLASS_NAME, "inventory_item")
    ADD_TO_CART_BTN  = (By.CSS_SELECTOR, "[data-test='add-to-cart-sauce-labs-backpack']")
    REMOVE_BTN       = (By.CSS_SELECTOR, "[data-test='remove-sauce-labs-backpack']")
    CART_BADGE       = (By.CLASS_NAME, "shopping_cart_badge")
    CART_ICON        = (By.CLASS_NAME, "shopping_cart_link")
    MENU_BUTTON      = (By.ID, "react-burger-menu-btn")
    LOGOUT_LINK      = (By.ID, "logout_sidebar_link")

    def get_page_title(self):
        """Return the page heading text."""
        return self.get_text(self.PAGE_TITLE)

    def get_product_count(self):
        """Return number of products displayed."""
        return len(self.find_elements(self.PRODUCT_ITEMS))

    def add_first_product_to_cart(self):
        """Add the first product (Sauce Labs Backpack) to the cart."""
        self.click(self.ADD_TO_CART_BTN)

    def remove_first_product_from_cart(self):
        """Remove the first product from the cart."""
        self.click(self.REMOVE_BTN)

    def get_cart_count(self):
        """Return the cart item count badge text."""
        return self.get_text(self.CART_BADGE)

    def is_cart_badge_visible(self):
        """Return True if cart badge is visible."""
        return self.is_element_visible(self.CART_BADGE)

    def logout(self):
        """Open the menu and click logout."""
        self.click(self.MENU_BUTTON)
        self.click(self.LOGOUT_LINK)
