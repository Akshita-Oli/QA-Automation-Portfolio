from selenium.webdriver.common.by import By
from pages.base_page import BasePage


class LoginPage(BasePage):
    """
    Page Object for the SauceDemo Login Page.
    URL: https://www.saucedemo.com
    """

    URL = "https://www.saucedemo.com"

    # Locators
    USERNAME_INPUT = (By.ID, "user-name")
    PASSWORD_INPUT = (By.ID, "password")
    LOGIN_BUTTON   = (By.ID, "login-button")
    ERROR_MESSAGE  = (By.CSS_SELECTOR, "[data-test='error']")

    def open(self):
        """Navigate to the login page."""
        self.driver.get(self.URL)

    def enter_username(self, username):
        """Type username into the username field."""
        self.type_text(self.USERNAME_INPUT, username)

    def enter_password(self, password):
        """Type password into the password field."""
        self.type_text(self.PASSWORD_INPUT, password)

    def click_login(self):
        """Click the login button."""
        self.click(self.LOGIN_BUTTON)

    def login(self, username, password):
        """Perform full login action."""
        self.enter_username(username)
        self.enter_password(password)
        self.click_login()

    def get_error_message(self):
        """Return the error message text."""
        return self.get_text(self.ERROR_MESSAGE)

    def is_error_displayed(self):
        """Return True if an error message is visible."""
        return self.is_element_visible(self.ERROR_MESSAGE)
