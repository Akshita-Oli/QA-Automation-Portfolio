# Selenium Python Automation Tests

Automated test suite for [SauceDemo](https://www.saucedemo.com) — a demo e-commerce application built for QA automation practice.

Built with **Python**, **Selenium WebDriver 4**, and **pytest** following the **Page Object Model (POM)** design pattern.

---

## Test Coverage

| Test Suite | Test Cases |
|---|---|
| Login | Valid login, Invalid credentials, Empty username, Empty password, Locked user |
| Products | Page title, Product count, Add to cart, Remove from cart, Logout |

---

## Tech Stack

- Python 3.8+
- Selenium WebDriver 4.x
- pytest
- webdriver-manager (automatic ChromeDriver setup)
- Page Object Model (POM) design pattern

---

## Project Structure

```
selenium-automation/
├── pages/
│   ├── base_page.py        # Reusable base methods (find, click, type)
│   ├── login_page.py       # Login page locators and actions
│   └── products_page.py    # Products page locators and actions
├── tests/
│   ├── test_login.py       # Login test scenarios (6 tests)
│   └── test_products.py    # Product and cart test scenarios (6 tests)
├── conftest.py             # WebDriver setup and teardown fixture
└── requirements.txt        # Project dependencies
```

---

## Setup & Run

### 1. Clone the repository
```bash
git clone [your-repo-url]
cd selenium-automation
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run all tests
```bash
pytest tests/ -v
```

### 4. Run with HTML report
```bash
pytest tests/ -v --html=report.html
```

### 5. Run a specific test file
```bash
pytest tests/test_login.py -v
```

---

## Test Site
Tests run against [SauceDemo](https://www.saucedemo.com) — a publicly available demo site built for automation practice.

| User | Password | Status |
|---|---|---|
| standard_user | secret_sauce | Valid user |
| locked_out_user | secret_sauce | Locked account |
| wrong_user | wrong_password | Invalid credentials |
