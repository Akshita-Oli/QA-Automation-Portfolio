import pytest
from pages.login_page import LoginPage
from pages.products_page import ProductsPage

# Test data
VALID_USER   = "standard_user"
VALID_PASS   = "secret_sauce"
INVALID_USER = "wrong_user"
INVALID_PASS = "wrong_password"
LOCKED_USER  = "locked_out_user"


class TestLogin:
    """Test suite covering all login scenarios."""

    def test_valid_login_redirects_to_products(self, driver):
        """Valid credentials should redirect to the Products page."""
        login_page = LoginPage(driver)
        login_page.open()
        login_page.login(VALID_USER, VALID_PASS)

        products_page = ProductsPage(driver)
        assert products_page.get_page_title() == "Products", \
            "Expected to land on Products page after successful login"

    def test_valid_login_url_changes(self, driver):
        """URL should change to inventory page after valid login."""
        login_page = LoginPage(driver)
        login_page.open()
        login_page.login(VALID_USER, VALID_PASS)

        assert "inventory" in driver.current_url, \
            "URL should contain 'inventory' after login"

    def test_invalid_credentials_shows_error(self, driver):
        """Invalid credentials should display an error message."""
        login_page = LoginPage(driver)
        login_page.open()
        login_page.login(INVALID_USER, INVALID_PASS)

        assert login_page.is_error_displayed(), \
            "Error message should be visible for invalid credentials"
        assert "Username and password do not match" in login_page.get_error_message()

    def test_empty_username_shows_error(self, driver):
        """Submitting with empty username should show an error."""
        login_page = LoginPage(driver)
        login_page.open()
        login_page.login("", VALID_PASS)

        assert login_page.is_error_displayed(), \
            "Error message should be visible when username is empty"
        assert "Username is required" in login_page.get_error_message()

    def test_empty_password_shows_error(self, driver):
        """Submitting with empty password should show an error."""
        login_page = LoginPage(driver)
        login_page.open()
        login_page.login(VALID_USER, "")

        assert login_page.is_error_displayed(), \
            "Error message should be visible when password is empty"
        assert "Password is required" in login_page.get_error_message()

    def test_locked_out_user_shows_error(self, driver):
        """Locked out user should see a specific error message."""
        login_page = LoginPage(driver)
        login_page.open()
        login_page.login(LOCKED_USER, VALID_PASS)

        assert login_page.is_error_displayed(), \
            "Error message should be visible for locked out user"
        assert "locked out" in login_page.get_error_message().lower()
