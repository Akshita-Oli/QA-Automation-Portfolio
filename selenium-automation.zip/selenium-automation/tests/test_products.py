import pytest
from pages.login_page import LoginPage
from pages.products_page import ProductsPage

VALID_USER = "standard_user"
VALID_PASS = "secret_sauce"


class TestProducts:
    """Test suite covering product listing and cart interactions."""

    @pytest.fixture(autouse=True)
    def login_before_each(self, driver):
        """Login before every test in this class."""
        login_page = LoginPage(driver)
        login_page.open()
        login_page.login(VALID_USER, VALID_PASS)
        self.products_page = ProductsPage(driver)

    def test_products_page_title_is_correct(self):
        """Products page should have the correct heading."""
        assert self.products_page.get_page_title() == "Products"

    def test_six_products_are_displayed(self):
        """Exactly 6 products should be visible on the page."""
        count = self.products_page.get_product_count()
        assert count == 6, f"Expected 6 products but found {count}"

    def test_products_count_is_greater_than_zero(self):
        """At least one product should be visible."""
        count = self.products_page.get_product_count()
        assert count > 0, "Products page should display at least one product"

    def test_add_product_updates_cart_badge(self):
        """Adding a product should show '1' on the cart badge."""
        self.products_page.add_first_product_to_cart()
        assert self.products_page.get_cart_count() == "1", \
            "Cart badge should show 1 after adding one product"

    def test_remove_product_hides_cart_badge(self):
        """Removing the only product should hide the cart badge."""
        self.products_page.add_first_product_to_cart()
        self.products_page.remove_first_product_from_cart()
        assert not self.products_page.is_cart_badge_visible(), \
            "Cart badge should not be visible after removing the only product"

    def test_logout_redirects_to_login(self):
        """Logging out should redirect the user back to the login page."""
        self.products_page.logout()
        assert "inventory" not in self.products_page.driver.current_url, \
            "User should be redirected away from inventory after logout"
