﻿using CommunityEventManagement.Data;
using CommunityEventManagement.Data.Models;
using CommunityEventManagement.Exceptions;
using CommunityEventManagement.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace CommunityEventManagement.Tests
{
    public class ParticipantServiceTests
    {
        #region AddParticipantAsync Tests

        [Fact]
        public async Task AddParticipantAsync_WithValidData_CreatesParticipantAndUser()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            // Setup UserManager to succeed
            mockUserManager.Setup(um => um.CreateAsync(It.IsAny<ApplicationUser>(), It.IsAny<string>()))
                .ReturnsAsync(IdentityResult.Success);
            mockUserManager.Setup(um => um.AddToRoleAsync(It.IsAny<ApplicationUser>(), "Participant"))
                .ReturnsAsync(IdentityResult.Success);

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT
            var participant = await service.AddParticipantAsync("John Doe", "john@example.com", "1234567890");

            // ASSERT
            Assert.NotNull(participant);
            Assert.Equal("John Doe", participant.FullName);
            Assert.Equal("john@example.com", participant.Email);
            Assert.Matches(@"USER\d{3}", participant.DisplayId); // e.g., USER001

            // Verify UserManager calls
            mockUserManager.Verify(um => um.CreateAsync(
                It.Is<ApplicationUser>(u =>
                    u.UserName == participant.DisplayId &&
                    u.Email == "john@example.com" &&
                    u.FullName == "John Doe"),
                "Password@123"), Times.Once);

            mockUserManager.Verify(um => um.AddToRoleAsync(
                It.IsAny<ApplicationUser>(), "Participant"), Times.Once);

            // Verify email sender was called
            mockEmailSender.Verify(es => es.SendEmailAsync(
                "john@example.com",
                "Your Participant Account Details",
                It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task AddParticipantAsync_WithDuplicateEmail_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            // Pre-add a participant with the same email (WITH ALL REQUIRED PROPERTIES)
            context.Participants.Add(new Participant
            {
                Id = 1,
                FullName = "Existing User",
                Email = "duplicate@example.com",
                PhoneNumber = "0000000000", 
                DisplayId = "USER001",
                UserId = "user001" 
            });
            await context.SaveChangesAsync();

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddParticipantAsync("New User", "duplicate@example.com", "1234567890"));

            Assert.Equal("A participant with this email already exists.", exception.Message);
        }

        [Fact]
        public async Task AddParticipantAsync_WhenUserCreationFails_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            // Setup UserManager to fail
            mockUserManager.Setup(um => um.CreateAsync(It.IsAny<ApplicationUser>(), It.IsAny<string>()))
                .ReturnsAsync(IdentityResult.Failed(new IdentityError { Description = "Invalid password" }));

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddParticipantAsync("Test", "test@example.com", "1234567890"));

            Assert.Contains("Failed to create user", exception.Message);
        }

        #endregion

        #region UpdateAsync Tests

        [Fact]
        public async Task UpdateAsync_WithValidChanges_UpdatesParticipant()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            var participant = new Participant
            {
                Id = 1,
                FullName = "Old Name",
                Email = "old@example.com",
                PhoneNumber = "0000000000",
                DisplayId = "USER001",
                UserId = "user001"
            };

            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(
                context,
                mockUserManager.Object,
                mockEmailSender.Object
            );

            // Modify the tracked entity (NO new instance)
            participant.FullName = "New Name";
            participant.Email = "new@example.com";
            participant.PhoneNumber = "1234567890";

            await service.UpdateAsync(participant);

            var saved = await context.Participants.FindAsync(1);
            Assert.NotNull(saved);
            Assert.Equal("New Name", saved!.FullName);
            Assert.Equal("new@example.com", saved.Email);
        }


        [Fact]
        public async Task UpdateAsync_WithDuplicateEmail_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            // Add two COMPLETE participants
            await context.Participants.AddRangeAsync(
                new Participant
                {
                    Id = 1,
                    Email = "user1@example.com",
                    FullName = "User 1",
                    PhoneNumber = "1111111111", 
                    DisplayId = "USER001",
                    UserId = "user001" 
                },
                new Participant
                {
                    Id = 2,
                    Email = "user2@example.com",
                    FullName = "User 2",
                    PhoneNumber = "2222222222", 
                    DisplayId = "USER002",
                    UserId = "user002" 
                }
            );
            await context.SaveChangesAsync();

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            var updatedParticipant = new Participant
            {
                Id = 1,
                Email = "user2@example.com", // Duplicate!
                FullName = "Updated",
                PhoneNumber = "1234567890",
                DisplayId = "USER001",
                UserId = "user001"
            };

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.UpdateAsync(updatedParticipant));

            Assert.Equal("A participant with this email already exists.", exception.Message);
        }

        [Fact]
        public async Task UpdateAsync_WithNullParticipant_ThrowsArgumentNullException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT & ASSERT
            await Assert.ThrowsAsync<ArgumentNullException>(() =>
                service.UpdateAsync(null!));
        }

        #endregion

        #region DeleteAsync Tests

        [Fact]
        public async Task DeleteAsync_DeletesParticipantAndUser()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            var participant = new Participant
            {
                Id = 1,
                UserId = "user123",
                FullName = "ToDelete",
                Email = "delete@example.com",
                PhoneNumber = "0000000000",
                DisplayId = "USER001"
            };

            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            
            context.Entry(participant).State = EntityState.Detached;

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            mockUserManager.Setup(um => um.FindByIdAsync("user123"))
                .ReturnsAsync(new ApplicationUser { Id = "user123" });
            mockUserManager.Setup(um => um.DeleteAsync(It.IsAny<ApplicationUser>()))
                .ReturnsAsync(IdentityResult.Success);

            var mockEmailSender = new Mock<IEmailSender>();
            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            await service.DeleteAsync(1);

            Assert.Null(await context.Participants.FindAsync(1));
        }


        [Fact]
        public async Task DeleteAsync_WhenUserNotFound_StillDeletesParticipant()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            var participant = new Participant
            {
                Id = 1,
                UserId = "missing-user",
                FullName = "ToDelete",
                Email = "delete@example.com",
                PhoneNumber = "0000000000",
                DisplayId = "USER001"
            };

            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            
            context.Entry(participant).State = EntityState.Detached;

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            mockUserManager.Setup(um => um.FindByIdAsync("missing-user"))
                .ReturnsAsync((ApplicationUser?)null);

            var mockEmailSender = new Mock<IEmailSender>();
            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            await service.DeleteAsync(1);

            Assert.Null(await context.Participants.FindAsync(1));
        }


        [Fact]
        public async Task DeleteAsync_CascadesToRegistrations()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            var participant = new Participant
            {
                Id = 1,
                UserId = "user123",
                FullName = "Test",
                Email = "test@example.com",
                PhoneNumber = "0000000000",
                DisplayId = "USER001"
            };

            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            context.Registrations.Add(new Registration
            {
                ParticipantId = 1,
                EventId = 1,
                Status = "Confirmed"
            });
            await context.SaveChangesAsync();

            // ✅ CRITICAL FIX
            context.Entry(participant).State = EntityState.Detached;

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            mockUserManager.Setup(um => um.FindByIdAsync("user123"))
                .ReturnsAsync(new ApplicationUser { Id = "user123" });
            mockUserManager.Setup(um => um.DeleteAsync(It.IsAny<ApplicationUser>()))
                .ReturnsAsync(IdentityResult.Success);

            var mockEmailSender = new Mock<IEmailSender>();
            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            await service.DeleteAsync(1);

            Assert.Empty(context.Registrations);
        }


        #endregion

        #region Helper Method Tests

        [Fact]
        public async Task GetByIdAsync_WithValidId_ReturnsParticipant()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            var participant = new Participant
            {
                Id = 1,
                FullName = "Find Me",
                Email = "find@example.com",
                PhoneNumber = "0000000000", // 👈 Fixed
                DisplayId = "USER001",
                UserId = "user001" // 👈 Fixed: Required!
            };
            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT
            var result = await service.GetByIdAsync(1);

            // ASSERT
            Assert.NotNull(result);
            Assert.Equal("Find Me", result!.FullName);
        }

        [Fact]
        public async Task GetByIdAsync_WithInvalidId_ThrowsNotFoundException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<NotFoundException>(() =>
                service.GetByIdAsync(999));

            Assert.Contains("Participant", exception.Message);
        }

        [Fact]
        public async Task GetByDisplayIdAsync_ReturnsParticipant()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            var participant = new Participant
            {
                Id = 1,
                FullName = "Test",
                Email = "test@example.com",
                PhoneNumber = "0000000000", // 👈 Fixed
                DisplayId = "USER999",
                UserId = "user999" // 👈 Fixed: Required!
            };
            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT
            var result = await service.GetByDisplayIdAsync("USER999");

            // ASSERT
            Assert.NotNull(result);
            Assert.Equal("USER999", result!.DisplayId);
        }

        [Fact]
        public async Task GetRegisteredEventsAsync_ReturnsEvents()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);

            // Add event
            var ev = new Event
            {
                EventId = 1,
                EventName = "Test Event",
                StartTime = DateTime.UtcNow.AddDays(1),
                EndTime = DateTime.UtcNow.AddDays(2)
            };
            context.Events.Add(ev);
            await context.SaveChangesAsync();

            // Add participant WITH REQUIRED UserId
            var participant = new Participant
            {
                Id = 1,
                FullName = "Test User",
                Email = "test@example.com",
                PhoneNumber = "1234567890",
                DisplayId = "USER001",
                UserId = "user123" // 👈 Required for registration
            };
            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            context.Registrations.Add(new Registration
            {
                ParticipantId = 1,
                EventId = 1,
                Status = "Confirmed"
            });
            await context.SaveChangesAsync();

            var mockUserManager = TestHelpers.CreateMockUserManager<ApplicationUser>();
            var mockEmailSender = new Mock<IEmailSender>();

            var service = new ParticipantService(context, mockUserManager.Object, mockEmailSender.Object);

            // ACT
            var events = await service.GetRegisteredEventsAsync(1);

            // ASSERT
            Assert.Single(events);
            Assert.Equal("Test Event", events[0].EventName);
        }

        #endregion
    }
}
