﻿using CommunityEventManagement.Data;
using CommunityEventManagement.Data.Models;
using CommunityEventManagement.Exceptions;
using CommunityEventManagement.Services;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace CommunityEventManagement.Tests
{
    public class ActivityServiceTests
    {
        #region AddAsync Tests

        [Fact]
        public async Task AddAsync_WithValidActivity_AddsSuccessfully()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            var newActivity = new Activity
            {
                ActivityName = "Yoga Class",
                ActivityType = "Fitness",
                Description = "Morning yoga session"
            };

            // ACT
            await service.AddAsync(newActivity);

            // ASSERT
            var savedActivity = await context.Activities.FindAsync(newActivity.ActivityId);
            Assert.NotNull(savedActivity);
            Assert.Equal("Yoga Class", savedActivity.ActivityName);
            Assert.Equal("Fitness", savedActivity.ActivityType);
        }

        [Fact]
        public async Task AddAsync_WithDuplicateName_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // Add first activity
            await context.Activities.AddAsync(new Activity
            {
                ActivityName = "Workshop",
                ActivityType = "Education",
                Description = "Basic workshop"
            });
            await context.SaveChangesAsync();

            var duplicateActivity = new Activity
            {
                ActivityName = "Workshop", // Same name!
                ActivityType = "Art",
                Description = "Advanced workshop"
            };

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddAsync(duplicateActivity));

            Assert.Equal("An activity with this name already exists.", exception.Message);
        }

        [Fact]
        public async Task AddAsync_WithEmptyName_DoesNotThrowException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            var activity = new Activity
            {
                ActivityName = "", // Empty name
                ActivityType = "Test",
                Description = "Test activity"
            };

            // ACT & ASSERT
            // Note: Your current ValidateUniqueNameAsync allows empty names
            await service.AddAsync(activity);
            var saved = await context.Activities.FindAsync(activity.ActivityId);
            Assert.NotNull(saved);
        }

        [Fact]
        public async Task AddAsync_WithWhitespaceName_DoesNotThrowException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            var activity = new Activity
            {
                ActivityName = "   ", // Whitespace-only name
                ActivityType = "Test",
                Description = "Test activity"
            };

            // ACT & ASSERT
            await service.AddAsync(activity);
            var saved = await context.Activities.FindAsync(activity.ActivityId);
            Assert.NotNull(saved);
        }

        [Fact]
        public async Task AddAsync_WithNullActivity_ThrowsArgumentNullException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // ACT & ASSERT
            await Assert.ThrowsAsync<ArgumentNullException>(() =>
                service.AddAsync(null!));
        }

        #endregion

        #region UpdateAsync Tests

        [Fact]
        public async Task UpdateAsync_WithValidChanges_UpdatesSuccessfully()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // Add initial activity
            var activity = new Activity
            {
                ActivityName = "Old Name",
                ActivityType = "Old Type",
                Description = "Old description"
            };
            context.Activities.Add(activity);
            await context.SaveChangesAsync();

            // Modify activity
            activity.ActivityName = "Updated Name";
            activity.Description = "New description";

            // ACT
            await service.UpdateAsync(activity);

            // ASSERT
            var updatedActivity = await context.Activities.FindAsync(activity.ActivityId);
            Assert.NotNull(updatedActivity);
            Assert.Equal("Updated Name", updatedActivity.ActivityName);
            Assert.Equal("New description", updatedActivity.Description);
        }

        [Fact]
        public async Task UpdateAsync_WithDuplicateName_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // Add two activities
            await context.Activities.AddRangeAsync(
                new Activity { ActivityName = "Activity A", ActivityType = "Type1" },
                new Activity { ActivityName = "Activity B", ActivityType = "Type2" }
            );
            await context.SaveChangesAsync();

            // Try to rename "Activity B" to "Activity A"
            var activityB = await context.Activities.FirstAsync(a => a.ActivityName == "Activity B");
            activityB.ActivityName = "Activity A";

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.UpdateAsync(activityB));

            Assert.Equal("An activity with this name already exists.", exception.Message);
        }

        [Fact]
        public async Task UpdateAsync_WithSameName_AllowsUpdate()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            var activity = new Activity
            {
                ActivityName = "Same Name",
                ActivityType = "Type",
                Description = "Original"
            };
            context.Activities.Add(activity);
            await context.SaveChangesAsync();

            // Update description but keep same name
            activity.Description = "Updated";

            // ACT
            await service.UpdateAsync(activity);

            // ASSERT
            var updated = await context.Activities.FindAsync(activity.ActivityId);
            Assert.NotNull(updated);
            Assert.Equal("Updated", updated.Description);
            // Should not throw exception
        }

        [Fact]
        public async Task UpdateAsync_WithNullActivity_ThrowsArgumentNullException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // ACT & ASSERT
            await Assert.ThrowsAsync<ArgumentNullException>(() =>
                service.UpdateAsync(null!));
        }

        #endregion

        #region DeleteAsync Tests

        [Fact]
        public async Task DeleteAsync_WithUnusedActivity_DeletesSuccessfully()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            var activity = new Activity
            {
                ActivityName = "ToDelete",
                ActivityType = "Test",
                Description = "Test activity"
            };
            context.Activities.Add(activity);
            await context.SaveChangesAsync();

            // ACT
            await service.DeleteAsync(activity.ActivityId);

            // ASSERT
            var deletedActivity = await context.Activities.FindAsync(activity.ActivityId);
            Assert.Null(deletedActivity);
        }

        [Fact]
        public async Task DeleteAsync_WithInUseActivity_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // Add activity and link to an event via EventActivity
            var activity = new Activity
            {
                ActivityName = "InUseActivity",
                ActivityType = "Test",
                Description = "Used in event"
            };
            context.Activities.Add(activity);
            await context.SaveChangesAsync();

            context.EventActivities.Add(new EventActivity
            {
                EventId = 1,
                ActivityId = activity.ActivityId
            });
            await context.SaveChangesAsync();

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.DeleteAsync(activity.ActivityId));

            Assert.Equal("Cannot delete activity that is associated with events.", exception.Message);
        }

        [Fact]
        public async Task DeleteAsync_WithNonExistentActivity_DoesNothing()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // ACT
            await service.DeleteAsync(999); // Non-existent ID

            // ASSERT
            // Should not throw an exception (silently succeeds)
            Assert.True(true);
        }

        #endregion

        #region GetByIdAsync Tests

        [Fact]
        public async Task GetByIdAsync_WithValidId_ReturnsActivity()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            var activity = new Activity
            {
                ActivityName = "FindMe",
                ActivityType = "Type",
                Description = "Test"
            };
            context.Activities.Add(activity);
            await context.SaveChangesAsync();

            // ACT
            var result = await service.GetByIdAsync(activity.ActivityId);

            // ASSERT
            Assert.NotNull(result);
            Assert.Equal("FindMe", result.ActivityName);
        }

        [Fact]
        public async Task GetByIdAsync_WithInvalidId_ThrowsNotFoundException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<NotFoundException>(() =>
                service.GetByIdAsync(999));

            Assert.Contains("Activity", exception.Message);
        }

        #endregion

        #region GetAllAsync Tests

        [Fact]
        public async Task GetAllAsync_ReturnsAllActivitiesOrderedByName()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            await context.Activities.AddRangeAsync(
                new Activity { ActivityName = "Z Activity" },
                new Activity { ActivityName = "A Activity" }
            );
            await context.SaveChangesAsync();

            // ACT
            var result = await service.GetAllAsync();

            // ASSERT
            Assert.Equal(2, result.Count);
            Assert.Equal("A Activity", result[0].ActivityName);
            Assert.Equal("Z Activity", result[1].ActivityName);
        }

        [Fact]
        public async Task GetAllAsync_WithNoActivities_ReturnsEmptyList()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new ActivityService(context);

            // ACT
            var result = await service.GetAllAsync();

            // ASSERT
            Assert.Empty(result);
        }

        #endregion
    }
}
