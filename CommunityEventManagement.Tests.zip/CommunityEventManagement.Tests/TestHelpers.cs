﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;

namespace CommunityEventManagement.Tests
{
    public static class TestHelpers
    {
        public static Mock<UserManager<TUser>> CreateMockUserManager<TUser>()
            where TUser : class
        {
            var store = new Mock<IUserStore<TUser>>();
            var options = new Mock<IOptions<IdentityOptions>>();
            options.Setup(o => o.Value).Returns(new IdentityOptions());

            var userValidators = new List<IUserValidator<TUser>>();
            var passwordValidators = new List<IPasswordValidator<TUser>>();

            var mock = new Mock<UserManager<TUser>>(
                store.Object,
                options.Object,
                Mock.Of<IPasswordHasher<TUser>>(),
                userValidators,
                passwordValidators,
                Mock.Of<ILookupNormalizer>(),
                Mock.Of<IdentityErrorDescriber>(),
                Mock.Of<IServiceProvider>(),
                Mock.Of<ILogger<UserManager<TUser>>>()
            );

            // Setup default behavior for CreateAsync to succeed
            mock.Setup(um => um.CreateAsync(It.IsAny<TUser>(), It.IsAny<string>()))
                .ReturnsAsync(IdentityResult.Success);

            // Setup AddToRoleAsync default
            mock.Setup(um => um.AddToRoleAsync(It.IsAny<TUser>(), It.IsAny<string>()))
                .ReturnsAsync(IdentityResult.Success);

            return mock;
        }
    }
}
