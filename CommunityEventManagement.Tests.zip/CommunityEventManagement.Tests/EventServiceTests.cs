﻿using CommunityEventManagement.Data;
using CommunityEventManagement.Data.Models;
using CommunityEventManagement.Exceptions;
using CommunityEventManagement.Services;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace CommunityEventManagement.Tests
{
    public class EventServiceTests
    {
        #region AddAsyncWithRelationships Tests

        [Fact]
        public async Task AddAsyncWithRelationships_WithValidEvent_CreatesSuccessfully()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            // Add prerequisite venues and activities
            var venue = new Venue { VenueName = "Hall", Address = "1 St", Capacity = 100 };
            var activity = new Activity { ActivityName = "Workshop", ActivityType = "Education" };
            context.Venues.Add(venue);
            context.Activities.Add(activity);
            await context.SaveChangesAsync();

            var futureDate = DateTime.UtcNow.AddDays(7);
            var newEvent = new Event
            {
                EventName = "Future Event",
                StartTime = futureDate,
                EndTime = futureDate.AddHours(2),
                Description = "Valid future event"
            };

            // ACT
            await service.AddAsyncWithRelationships(newEvent, new List<int> { venue.VenueId }, new List<int> { activity.ActivityId });

            // ASSERT
            var savedEvent = await context.Events.FindAsync(newEvent.EventId);
            Assert.NotNull(savedEvent);
            Assert.Equal("Future Event", savedEvent.EventName);

            var eventVenues = await context.EventVenues.Where(ev => ev.EventId == newEvent.EventId).ToListAsync();
            Assert.Single(eventVenues);
            Assert.Equal(venue.VenueId, eventVenues[0].VenueId);

            var eventActivities = await context.EventActivities.Where(ea => ea.EventId == newEvent.EventId).ToListAsync();
            Assert.Single(eventActivities);
            Assert.Equal(activity.ActivityId, eventActivities[0].ActivityId);
        }

        [Fact]
        public async Task AddAsyncWithRelationships_WithPastStartDate_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var pastEvent = new Event
            {
                EventName = "Past Event",
                StartTime = DateTime.UtcNow.AddDays(-1), // Past start time
                EndTime = DateTime.UtcNow.AddHours(1),
                Description = "Should be rejected"
            };

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddAsyncWithRelationships(pastEvent, new List<int>(), new List<int>()));

            Assert.Contains("future", exception.Message);
        }

        [Fact]
        public async Task AddAsyncWithRelationships_WithDuplicateName_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var futureDate = DateTime.UtcNow.AddDays(7);
            await context.Events.AddAsync(new Event
            {
                EventName = "Duplicate Event",
                StartTime = futureDate,
                EndTime = futureDate.AddHours(2)
            });
            await context.SaveChangesAsync();

            var duplicateEvent = new Event
            {
                EventName = "Duplicate Event", // Same name
                StartTime = futureDate.AddDays(1),
                EndTime = futureDate.AddDays(1).AddHours(2)
            };

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddAsyncWithRelationships(duplicateEvent, new List<int>(), new List<int>()));

            Assert.Contains("already exists", exception.Message);
        }

        [Fact]
        public async Task AddAsyncWithRelationships_WithVenueConflict_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            // Add venue
            var venue = new Venue { VenueName = "Hall", Address = "1 St", Capacity = 100 };
            context.Venues.Add(venue);
            await context.SaveChangesAsync();

            var startDate = DateTime.UtcNow.AddDays(5);
            var endDate = startDate.AddHours(3);

            // Add conflicting event
            await context.Events.AddRangeAsync(
                new Event
                {
                    EventName = "Event 1",
                    StartTime = startDate,
                    EndTime = endDate
                }
            );
            await context.SaveChangesAsync();

            var eventId1 = context.Events.First().EventId;
            context.EventVenues.Add(new EventVenue { EventId = eventId1, VenueId = venue.VenueId });
            await context.SaveChangesAsync();

            // New event with time overlap
            var overlappingEvent = new Event
            {
                EventName = "Overlapping Event",
                StartTime = startDate.AddHours(1), // Overlaps with Event 1
                EndTime = startDate.AddHours(4)
            };

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddAsyncWithRelationships(overlappingEvent, new List<int> { venue.VenueId }, new List<int>()));

            Assert.Contains("booked", exception.Message);
        }

        [Fact]
        public async Task AddAsyncWithRelationships_WithNoVenues_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var futureDate = DateTime.UtcNow.AddDays(7);
            var newEvent = new Event
            {
                EventName = "No Venue Event",
                StartTime = futureDate,
                EndTime = futureDate.AddHours(2)
            };

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddAsyncWithRelationships(newEvent, new List<int>(), new List<int>()));

            Assert.Contains("venue", exception.Message);
        }

        #endregion

        #region UpdateAsyncWithRelationships Tests

        [Fact]
        public async Task UpdateAsyncWithRelationships_WithValidChanges_UpdatesSuccessfully()
        {
            // ARRANGE - Create in-memory DB
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            // Setup initial data
            using (var context = new ApplicationDbContext(options))
            {
                // Add venues
                var venue1 = new Venue { VenueName = "Hall 1", Address = "1 St", Capacity = 100 };
                var venue2 = new Venue { VenueName = "Hall 2", Address = "2 St", Capacity = 150 };
                context.Venues.AddRange(venue1, venue2);
                await context.SaveChangesAsync();

                // Add original event
                var startDate = DateTime.UtcNow.AddDays(10);
                var originalEvent = new Event
                {
                    EventName = "Original Event",
                    StartTime = startDate,
                    EndTime = startDate.AddHours(2)
                };
                context.Events.Add(originalEvent);
                await context.SaveChangesAsync();

                // Link original event to venue1
                context.EventVenues.Add(new EventVenue { EventId = originalEvent.EventId, VenueId = venue1.VenueId });
                await context.SaveChangesAsync();
            }

            // ACT - Update using a new DbContext
            using (var context = new ApplicationDbContext(options))
            {
                var service = new EventService(context);

                // Fetch the tracked event from DbContext
                var updatedEvent = await context.Events
                    .Include(e => e.EventVenues)
                    .FirstAsync();

                // Modify its properties
                updatedEvent.EventName = "Updated Event";
                updatedEvent.StartTime = DateTime.UtcNow.AddDays(11);
                updatedEvent.EndTime = DateTime.UtcNow.AddDays(11).AddHours(3);

                // Update venue relationships (replace with venue2)
                await service.UpdateAsyncWithRelationships(updatedEvent, new List<int> { 2 }, new List<int>());
            }

            // ASSERT - Verify updated data
            using (var context = new ApplicationDbContext(options))
            {
                var savedEvent = await context.Events.FindAsync(1);
                Assert.NotNull(savedEvent);
                Assert.Equal("Updated Event", savedEvent!.EventName);

                var venues = await context.EventVenues.Where(ev => ev.EventId == 1).ToListAsync();
                Assert.Single(venues);
                Assert.Equal(2, venues[0].VenueId);
            }
        }


        [Fact]
        public async Task UpdateAsyncWithRelationships_WithPastTime_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var futureDate = DateTime.UtcNow.AddDays(5);
            var existingEvent = new Event
            {
                EventName = "Future Event",
                StartTime = futureDate,
                EndTime = futureDate.AddHours(2)
            };
            context.Events.Add(existingEvent);
            await context.SaveChangesAsync();

            // Try to update to past time
            var updatedEvent = new Event
            {
                EventId = existingEvent.EventId,
                EventName = "Past Event",
                StartTime = DateTime.UtcNow.AddDays(-1),
                EndTime = DateTime.UtcNow.AddHours(1)
            };

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.UpdateAsyncWithRelationships(updatedEvent, new List<int>(), new List<int>()));

            Assert.Contains("future", exception.Message);
        }

        #endregion

        #region DeleteAsync Tests

        [Fact]
        public async Task DeleteAsync_WithFutureEvent_DeletesSuccessfully()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var futureDate = DateTime.UtcNow.AddDays(5);
            var eventToDelete = new Event
            {
                EventName = "Deletable Event",
                StartTime = futureDate,
                EndTime = futureDate.AddHours(2)
            };
            context.Events.Add(eventToDelete);
            await context.SaveChangesAsync();

            // ACT
            await service.DeleteAsync(eventToDelete.EventId);

            // ASSERT
            var deletedEvent = await context.Events.FindAsync(eventToDelete.EventId);
            Assert.Null(deletedEvent);
        }

        [Fact]
        public async Task DeleteAsync_WithOngoingEvent_ThrowsBusinessRuleViolationException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var ongoingEvent = new Event
            {
                EventName = "Ongoing Event",
                StartTime = DateTime.UtcNow.AddHours(-1), // Started 1 hour ago
                EndTime = DateTime.UtcNow.AddHours(1)     // Ends in 1 hour
            };
            context.Events.Add(ongoingEvent);
            await context.SaveChangesAsync();

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.DeleteAsync(ongoingEvent.EventId));

            Assert.Contains("ongoing", exception.Message);
        }

        [Fact]
        public async Task DeleteAsync_WithPastEvent_DeletesSuccessfully()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var pastEvent = new Event
            {
                EventName = "Past Event",
                StartTime = DateTime.UtcNow.AddDays(-2),
                EndTime = DateTime.UtcNow.AddDays(-1)
            };
            context.Events.Add(pastEvent);
            await context.SaveChangesAsync();

            // ACT
            await service.DeleteAsync(pastEvent.EventId);

            // ASSERT
            var deletedEvent = await context.Events.FindAsync(pastEvent.EventId);
            Assert.Null(deletedEvent);
        }

        [Fact]
        public async Task DeleteAsync_CascadesToRegistrationsAndRelationships()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            // Create event
            var futureDate = DateTime.UtcNow.AddDays(5);
            var ev = new Event
            {
                EventName = "Cascading Event",
                StartTime = futureDate,
                EndTime = futureDate.AddHours(2)
            };
            context.Events.Add(ev);
            await context.SaveChangesAsync();

            // Add registration WITH REQUIRED UserId
            var participant = new Participant
            {
                Id = 1,
                FullName = "Test",
                Email = "test@test.com",
                PhoneNumber = "123",
                DisplayId = "USER001",
                UserId = "user123" 
            };
            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            context.Registrations.Add(new Registration
            {
                EventId = ev.EventId,
                ParticipantId = participant.Id,
                Status = "Confirmed"
            });

            // Add relationships
            var venue = new Venue
            {
                VenueName = "Hall",
                Address = "1 St",
                Capacity = 100
            };
            context.Venues.Add(venue);
            await context.SaveChangesAsync();

            context.EventVenues.Add(new EventVenue { EventId = ev.EventId, VenueId = venue.VenueId });
            context.EventActivities.Add(new EventActivity { EventId = ev.EventId, ActivityId = 1 });

            await context.SaveChangesAsync();

            // ACT
            await service.DeleteAsync(ev.EventId);

            // ASSERT
            Assert.Empty(context.Registrations);
            Assert.Empty(context.EventVenues);
            Assert.Empty(context.EventActivities);
        }

        #endregion

        #region Get Methods Tests

        [Fact]
        public async Task GetUpcomingFilteredAsync_WithFutureEvents_ReturnsOnlyFutureEvents()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var now = DateTime.UtcNow;
            await context.Events.AddRangeAsync(
                new Event { EventName = "Past", StartTime = now.AddDays(-2), EndTime = now.AddDays(-1) },
                new Event { EventName = "Ongoing", StartTime = now.AddHours(-1), EndTime = now.AddHours(1) },
                new Event { EventName = "Future", StartTime = now.AddDays(1), EndTime = now.AddDays(2) }
            );
            await context.SaveChangesAsync();

            // ACT
            var result = await service.GetUpcomingFilteredAsync();

            // ASSERT
            Assert.Single(result);
            Assert.Equal("Future", result[0].EventName);
        }

        [Fact]
        public async Task GetFilteredAsync_WithAllEvents_ReturnsPastAndFuture()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var now = DateTime.UtcNow;
            await context.Events.AddRangeAsync(
                new Event { EventName = "Past", StartTime = now.AddDays(-2), EndTime = now.AddDays(-1) },
                new Event { EventName = "Future", StartTime = now.AddDays(1), EndTime = now.AddDays(2) }
            );
            await context.SaveChangesAsync();

            // ACT
            var result = await service.GetFilteredAsync();

            // ASSERT
            Assert.Equal(2, result.Count);
        }

        [Fact]
        public async Task GetByIdAsync_WithValidId_ReturnsEventWithRelationships()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            var ev = new Event
            {
                EventName = "Test Event",
                StartTime = DateTime.UtcNow.AddDays(1),
                EndTime = DateTime.UtcNow.AddDays(2)
            };
            context.Events.Add(ev);
            await context.SaveChangesAsync();

            var venue = new Venue { VenueName = "Hall", Address = "1 St", Capacity = 100 };
            context.Venues.Add(venue);
            await context.SaveChangesAsync();

            context.EventVenues.Add(new EventVenue { EventId = ev.EventId, VenueId = venue.VenueId });
            await context.SaveChangesAsync();

            // ACT
            var result = await service.GetByIdAsync(ev.EventId);

            // ASSERT
            Assert.NotNull(result);
            Assert.Equal("Test Event", result.EventName);
            Assert.Single(result.EventVenues);
            Assert.Equal("Hall", result.EventVenues.First().Venue.VenueName);
        }

        [Fact]
        public async Task GetByIdAsync_WithInvalidId_ThrowsNotFoundException()
        {
            // ARRANGE
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new EventService(context);

            // ACT & ASSERT
            var exception = await Assert.ThrowsAsync<NotFoundException>(() =>
                service.GetByIdAsync(999));

            Assert.Contains("Event", exception.Message);
        }

        #endregion

        #region Helper Methods Tests

        [Fact]
        public void GetEventStatus_WithPastEvent_ReturnsPast()
        {
            // ARRANGE
            var service = new EventService(new ApplicationDbContext(new DbContextOptionsBuilder<ApplicationDbContext>().Options));
            var pastEvent = new Event
            {
                StartTime = DateTime.UtcNow.AddDays(-2),
                EndTime = DateTime.UtcNow.AddDays(-1)
            };

            // ACT
            var status = service.GetEventStatus(pastEvent);

            // ASSERT
            Assert.Equal("Past", status);
        }

        [Fact]
        public void GetEventStatus_WithOngoingEvent_ReturnsOngoing()
        {
            // ARRANGE
            var service = new EventService(new ApplicationDbContext(new DbContextOptionsBuilder<ApplicationDbContext>().Options));
            var ongoingEvent = new Event
            {
                StartTime = DateTime.UtcNow.AddHours(-1),
                EndTime = DateTime.UtcNow.AddHours(1)
            };

            // ACT
            var status = service.GetEventStatus(ongoingEvent);

            // ASSERT
            Assert.Equal("Ongoing", status);
        }

        [Fact]
        public void GetEventStatus_WithFutureEvent_ReturnsFuture()
        {
            // ARRANGE
            var service = new EventService(new ApplicationDbContext(new DbContextOptionsBuilder<ApplicationDbContext>().Options));
            var futureEvent = new Event
            {
                StartTime = DateTime.UtcNow.AddDays(1),
                EndTime = DateTime.UtcNow.AddDays(2)
            };

            // ACT
            var status = service.GetEventStatus(futureEvent);

            // ASSERT
            Assert.Equal("Future", status);
        }

        #endregion
    }
}
