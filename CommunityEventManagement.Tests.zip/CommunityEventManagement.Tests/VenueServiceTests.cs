﻿using CommunityEventManagement.Data;
using CommunityEventManagement.Data.Models;
using CommunityEventManagement.Exceptions;
using CommunityEventManagement.Services;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace CommunityEventManagement.Tests
{
    public class VenueServiceTests
    {
        #region AddAsync Tests

        [Fact]
        public async Task AddAsync_WithValidVenue_AddsSuccessfully()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            var newVenue = new Venue
            {
                VenueName = "Community Centre",
                Address = "123 Main St",
                Capacity = 150
            };

            await service.AddAsync(newVenue);

            var savedVenue = await context.Venues.FindAsync(newVenue.VenueId);
            Assert.NotNull(savedVenue);
            Assert.Equal("Community Centre", savedVenue.VenueName);
            Assert.Equal(150, savedVenue.Capacity);
        }

        [Fact]
        public async Task AddAsync_WithDuplicateName_ThrowsBusinessRuleViolationException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            await context.Venues.AddAsync(new Venue
            {
                VenueName = "Town Hall",
                Address = "1 High St",
                Capacity = 200
            });
            await context.SaveChangesAsync();

            var duplicateVenue = new Venue
            {
                VenueName = "Town Hall",
                Address = "2 High St",
                Capacity = 100
            };

            var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddAsync(duplicateVenue));

            Assert.Equal("A venue with this name already exists.", ex.Message);
        }

        [Fact]
        public async Task AddAsync_WithInvalidCapacity_ThrowsBusinessRuleViolationException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            var invalidVenue = new Venue
            {
                VenueName = "Invalid Venue",
                Address = "123 St",
                Capacity = 0
            };

            var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.AddAsync(invalidVenue));

            Assert.Equal("Venue capacity must be greater than 0.", ex.Message);
        }

        [Fact]
        public async Task AddAsync_WithNullVenue_ThrowsArgumentNullException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            await Assert.ThrowsAsync<ArgumentNullException>(() =>
                service.AddAsync(null!));
        }

        #endregion

        #region UpdateAsync Tests

        [Fact]
        public async Task UpdateAsync_WithValidChanges_UpdatesSuccessfully()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            var venue = new Venue
            {
                VenueName = "Old Name",
                Address = "Old Address",
                Capacity = 100
            };
            await context.Venues.AddAsync(venue);
            await context.SaveChangesAsync();

            venue.VenueName = "Updated Name";
            venue.Capacity = 250;

            await service.UpdateAsync(venue);

            var updatedVenue = await context.Venues.FindAsync(venue.VenueId);
            Assert.NotNull(updatedVenue);
            Assert.Equal("Updated Name", updatedVenue.VenueName);
            Assert.Equal(250, updatedVenue.Capacity);
        }

        [Fact]
        public async Task UpdateAsync_WithDuplicateName_ThrowsBusinessRuleViolationException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            await context.Venues.AddRangeAsync(
                new Venue { VenueName = "Venue A", Address = "A", Capacity = 100 },
                new Venue { VenueName = "Venue B", Address = "B", Capacity = 200 }
            );
            await context.SaveChangesAsync();

            var venueB = await context.Venues.FirstAsync(v => v.VenueName == "Venue B");
            venueB.VenueName = "Venue A";

            var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.UpdateAsync(venueB));

            Assert.Equal("A venue with this name already exists.", ex.Message);
        }

        [Fact]
        public async Task UpdateAsync_WithInvalidCapacity_ThrowsBusinessRuleViolationException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            var venue = new Venue
            {
                VenueName = "Test Venue",
                Address = "123 St",
                Capacity = 100
            };
            await context.Venues.AddAsync(venue);
            await context.SaveChangesAsync();

            venue.Capacity = 0;

            var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.UpdateAsync(venue));

            Assert.Equal("Venue capacity must be greater than 0.", ex.Message);
        }

        [Fact]
        public async Task UpdateAsync_WithNullVenue_ThrowsArgumentNullException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            await Assert.ThrowsAsync<ArgumentNullException>(() =>
                service.UpdateAsync(null!));
        }

        #endregion

        #region DeleteAsync Tests

        [Fact]
        public async Task DeleteAsync_WithUnusedVenue_DeletesSuccessfully()
        {
            var dbName = Guid.NewGuid().ToString();
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: dbName)
                .Options;

            // 1. SETUP: Create venue in first context
            using (var setupContext = new ApplicationDbContext(options))
            {
                var venue = new Venue
                {
                    VenueName = "To Delete",
                    Address = "123 St",
                    Capacity = 50
                };
                await setupContext.Venues.AddAsync(venue);
                await setupContext.SaveChangesAsync();
            }

            // 2. ACT: Delete using a FRESH context (like real HTTP request)
            using (var actContext = new ApplicationDbContext(options))
            {
                var service = new VenueService(actContext);
                await service.DeleteAsync(1); // VenueId is 1 (first record)
            }

            // 3. ASSERT: Verify deletion in a THIRD context
            using (var assertContext = new ApplicationDbContext(options))
            {
                var deletedVenue = await assertContext.Venues.FindAsync(1);
                Assert.Null(deletedVenue);
            }
        }

        [Fact]
        public async Task DeleteAsync_WithInUseVenue_ThrowsBusinessRuleViolationException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            var venue = new Venue
            {
                VenueName = "In Use Venue",
                Address = "123 St",
                Capacity = 100
            };
            await context.Venues.AddAsync(venue);
            await context.SaveChangesAsync();

            context.EventVenues.Add(new EventVenue
            {
                EventId = 1,
                VenueId = venue.VenueId
            });
            await context.SaveChangesAsync();

            var ex = await Assert.ThrowsAsync<BusinessRuleViolationException>(() =>
                service.DeleteAsync(venue.VenueId));

            Assert.Equal("Cannot delete venue that is associated with events.", ex.Message);
        }

        [Fact]
        public async Task DeleteAsync_WithNonExistentVenue_DoesNothing()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            await service.DeleteAsync(999); // Non-existent ID
            Assert.True(true); // silently succeeds
        }

        #endregion

        #region GetByIdAsync Tests

        [Fact]
        public async Task GetByIdAsync_WithValidId_ReturnsVenue()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            var venue = new Venue
            {
                VenueName = "Find Me",
                Address = "123 St",
                Capacity = 75
            };
            await context.Venues.AddAsync(venue);
            await context.SaveChangesAsync();

            var result = await service.GetByIdAsync(venue.VenueId);

            Assert.NotNull(result);
            Assert.Equal("Find Me", result.VenueName);
        }

        [Fact]
        public async Task GetByIdAsync_WithInvalidId_ThrowsNotFoundException()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ApplicationDbContext(options);
            var service = new VenueService(context);

            var ex = await Assert.ThrowsAsync<NotFoundException>(() =>
                service.GetByIdAsync(999));

            Assert.Contains("Venue", ex.Message);
        }

        #endregion
    }
}
